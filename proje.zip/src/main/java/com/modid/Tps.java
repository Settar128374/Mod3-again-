package com.modid;

/** Sunucu TPS tahmini. WorldTimeUpdate paketleri ~20 tickte bir (1 sn) gelir. */
public final class Tps {
    private Tps() {}

    private static final float[] RING = new float[5];
    private static int count, idx;
    private static long last;

    public static void onPacket() {
        long now = System.nanoTime();
        if (last != 0) {
            double dt = (now - last) / 1.0E9;
            if (dt > 0.05) {
                float t = (float) Math.min(20.0, Math.max(0.0, 20.0 / dt));
                RING[idx] = t;
                idx = (idx + 1) % RING.length;
                count = Math.min(count + 1, RING.length);
            }
        }
        last = now;
    }

    public static float get() {
        if (count == 0) return 20f;
        float s = 0;
        for (int i = 0; i < count; i++) s += RING[i];
        return s / count;
    }

    public static void reset() { count = 0; idx = 0; last = 0; }
}
