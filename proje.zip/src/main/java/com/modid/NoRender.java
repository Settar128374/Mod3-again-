package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * Render kategorisi: NoRender.
 * Asıl işi com.modid.mixin.* sınıfları yapar; bu sınıf sadece ayarları ve yardımcıları tutar.
 * Mixin'ler modid.extras.mixins.json içinde (required:false) olduğu için hatalı bir hedef oyunu çökertmez.
 */
public class NoRender extends Module {
    public static final NoRender I = new NoRender();

    public static void register() {
        Modules.ALL.add(I);
    }

    // ---- Ekran efektleri
    public final Setting.Bool fire = add(new Setting.Bool("Fire", true));
    public final Setting.Num fireHeight = add(new Setting.Num("Fire Height", 0.0, 0.0, 1.0, 0.05));
    public final Setting.Bool hurtCam = add(new Setting.Bool("HurtCam", true));
    public final Setting.Bool pumpkin = add(new Setting.Bool("Pumpkin", true));
    public final Setting.Bool portal = add(new Setting.Bool("Portal", true));
    public final Setting.Bool nausea = add(new Setting.Bool("Nausea", true));
    public final Setting.Bool blindness = add(new Setting.Bool("Blindness", true));
    public final Setting.Bool totem = add(new Setting.Bool("Totem", true));
    public final Setting.Bool itemOverlay = add(new Setting.Bool("Item Overlay", true));
    public final Setting.Bool vignette = add(new Setting.Bool("Vignette", true));

    // ---- Zırh
    public final Setting.Bool armorAll = add(new Setting.Bool("Armor (All)", false));
    public final Setting.Bool helmet = add(new Setting.Bool("Armor: Helmet", false));
    public final Setting.Bool chest = add(new Setting.Bool("Armor: Chestplate", false));
    public final Setting.Bool legs = add(new Setting.Bool("Armor: Leggings", false));
    public final Setting.Bool boots = add(new Setting.Bool("Armor: Boots", false));

    // ---- HUD
    public final Setting.Bool bossBar = add(new Setting.Bool("BossBar", false));
    public final Setting.Bool scoreboard = add(new Setting.Bool("Scoreboard", false));

    // ---- Parçacıklar
    public final Setting.Bool explosions = add(new Setting.Bool("Explosions", true));
    public final Setting.Bool crit = add(new Setting.Bool("Crit Particles", false));
    public final Setting.Bool potion = add(new Setting.Bool("Potion Particles", false));
    public final Setting.Bool spell = add(new Setting.Bool("Spell / Magic", false));
    public final Setting.Bool smoke = add(new Setting.Bool("Smoke", false));
    public final Setting.Bool bubble = add(new Setting.Bool("Bubble", false));
    public final Setting.Bool weather = add(new Setting.Bool("Weather", false));

    // ---- Dünya
    public final Setting.Bool light = add(new Setting.Bool("Light (Fullbright)", false));
    public final Setting.Bool items = add(new Setting.Bool("Dropped Items (hide)", false));
    public final Setting.Bool glint = add(new Setting.Bool("Enchant Glint", false));
    public final Setting.Bool maps = add(new Setting.Bool("Maps", false));
    public final Setting.Bool entities = add(new Setting.Bool("Entities (distance)", false));
    public final Setting.Num entityDist = add(new Setting.Num("Entity Distance", 64, 0, 256, 1));
    public final Setting.Bool tiles = add(new Setting.Bool("TileEntities (distance)", false));
    public final Setting.Num tileDist = add(new Setting.Num("TileEntity Distance", 64, 0, 256, 1));
    public final Setting.Bool signText = add(new Setting.Bool("Sign Text", false));
    public final Setting.Bool fog = add(new Setting.Bool("Fog", true));
    public final Setting.Bool glitch = add(new Setting.Bool("Glitch / Distortion", true));

    /** Fire Height için ModelView yığınına push yapıldı mı (mixin kullanır). */
    public boolean firePushed;
    private boolean fbSet;

    public NoRender() {
        super("No Render", "Render");
    }

    // ------------------------------------------------------------ yaşam döngüsü

    @Override
    public void onTick(MinecraftClient mc) {
        if (light.get()) {
            if (!Modules.FULLBRIGHT.isEnabled()) {
                Modules.FULLBRIGHT.setEnabled(true);
                fbSet = true;
            }
        } else if (fbSet) {
            Modules.FULLBRIGHT.setEnabled(false);
            fbSet = false;
        }
    }

    @Override
    public void onDisable() {
        if (fbSet) {
            Modules.FULLBRIGHT.setEnabled(false);
            fbSet = false;
        }
    }

    // ------------------------------------------------------------ mixin yardımcıları

    /** Modül açık VE ilgili ayar açık mı? */
    public static boolean on(Setting.Bool b) {
        return I.isEnabled() && b.get();
    }

    public static boolean hideArmor(EquipmentSlot slot) {
        if (!I.isEnabled()) return false;
        if (I.armorAll.get()) return true;
        return switch (slot) {
            case HEAD -> I.helmet.get();
            case CHEST -> I.chest.get();
            case LEGS -> I.legs.get();
            case FEET -> I.boots.get();
            default -> false;
        };
    }

    public static boolean blocked(ParticleEffect effect) {
        if (!I.isEnabled() || effect == null) return false;
        ParticleType<?> t = effect.getType();

        if (I.crit.get() && (t == ParticleTypes.CRIT || t == ParticleTypes.ENCHANTED_HIT)) return true;
        if (I.potion.get() && t == ParticleTypes.ENTITY_EFFECT) return true;
        if (I.spell.get() && (t == ParticleTypes.EFFECT || t == ParticleTypes.INSTANT_EFFECT
                || t == ParticleTypes.WITCH || t == ParticleTypes.ENCHANT)) return true;
        if (I.smoke.get() && (t == ParticleTypes.SMOKE || t == ParticleTypes.LARGE_SMOKE
                || t == ParticleTypes.CAMPFIRE_COSY_SMOKE || t == ParticleTypes.CAMPFIRE_SIGNAL_SMOKE)) return true;
        if (I.bubble.get() && (t == ParticleTypes.BUBBLE || t == ParticleTypes.BUBBLE_POP
                || t == ParticleTypes.BUBBLE_COLUMN_UP || t == ParticleTypes.CURRENT_DOWN)) return true;
        if (I.explosions.get() && (t == ParticleTypes.EXPLOSION || t == ParticleTypes.EXPLOSION_EMITTER
                || t == ParticleTypes.LARGE_SMOKE)) return true;
        return I.totem.get() && t == ParticleTypes.TOTEM_OF_UNDYING;
    }

    private static Vec3d camPos() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.gameRenderer.getCamera().getPos();
    }

    public static boolean entityTooFar(net.minecraft.entity.Entity e) {
        if (!I.isEnabled() || !I.entities.get()) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (e == mc.player) return false;
        double d = I.entityDist.get();
        return e.squaredDistanceTo(camPos()) > d * d;
    }

    public static boolean tileTooFar(net.minecraft.block.entity.BlockEntity be) {
        if (!I.isEnabled() || !I.tiles.get()) return false;
        double d = I.tileDist.get();
        return Vec3d.ofCenter(be.getPos()).squaredDistanceTo(camPos()) > d * d;
    }
}
