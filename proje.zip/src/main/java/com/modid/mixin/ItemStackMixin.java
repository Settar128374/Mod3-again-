package com.modid.mixin;

import com.modid.NoRender;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
    @Inject(method = "hasGlint", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$glint(CallbackInfoReturnable<Boolean> cir) {
        if (NoRender.on(NoRender.I.glint)) cir.setReturnValue(false);
    }
}
