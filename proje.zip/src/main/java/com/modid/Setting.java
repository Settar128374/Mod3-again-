package com.modid;

import java.util.Locale;

public abstract class Setting {
	public final String name;

	protected Setting(String name) {
		this.name = name;
	}

	/** Kaydirmali sayi ayari (ornek: Range) */
	public static class Num extends Setting {
		public final double min, max, step;
		private double value;

		public Num(String name, double def, double min, double max, double step) {
			super(name);
			this.min = min;
			this.max = max;
			this.step = step;
			this.value = def;
		}

		public double get() {
			return value;
		}

		public void set(double v) {
			v = Math.max(min, Math.min(max, v));
			v = Math.round(v / step) * step;
			value = Math.max(min, Math.min(max, v));
		}

		public String display() {
			if (step >= 1) return String.valueOf((int) Math.round(value));
			return String.format(Locale.ROOT, step < 0.1 ? "%.2f" : "%.1f", value);
		}
	}

	/** Ac/kapa ayari */
	public static class Bool extends Setting {
		private boolean value;

		public Bool(String name, boolean def) {
			super(name);
			this.value = def;
		}

		public boolean get() {
			return value;
		}

		public void toggle() {
			value = !value;
		}
	}

	/** Secenek listesi ayari (tiklayinca siradakine gecer) */
	public static class Mode extends Setting {
		private final String[] modes;
		private int index;

		public Mode(String name, String... modes) {
			super(name);
			this.modes = modes;
		}

		public String get() {
			return modes[index];
		}

		public void next() {
			index = (index + 1) % modes.length;
		}
	}
}
